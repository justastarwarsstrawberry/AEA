![intro](https://hatred2k.com/assets/hydra.jpg)

# Hydra - A multipurpose discord bot made by xNathanz.
<h4 align="center">Moderation, utility, and much more!</h4>
<p align="center">
  <a href="https://discord.gg/TWxeQGx">
    <img src="https://discordapp.com/api/guilds/556510395150499850/widget.png?style=shield" alt="Discord Server">
  </a>
  <a href="https://Discord.js.org">
      <img src="https://img.shields.io/badge/discord-js-blue.svg" alt="Discord.js.org">
  </a>
   <a href="https://discord.js.org/#/">
    <img src="https://forthebadge.com/images/badges/made-with-javascript.svg" alt="Made with JavaScript">
  </a>
</p>

Hydra is a fully functional discord bot.

# Installation
* [Windows]()
* [Ubuntu]()

# Support

I am new to coding and i'm learning as i go, If you have any issues please join my Discord so i can help you further.

# License

Released under the [MIT](LICENSE).

# Credits

[DiscordJS Community](https://discord.js.org/#/)
